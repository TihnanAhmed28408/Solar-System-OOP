import unittest
from star import Star
''' module contains unittests for the star class using unittest framwwork '''

class TestStar(unittest.TestCase):
    """
    A test case class for testing the Star class 
    """
    
    def test_attributes(self):
        """
        Tests that the attributes are correctly assigned
        during initialization.
        """
        star = Star("Sirius", 3.978e30, "A-type") # mock star we use for testing

        self.assertEqual(star.name, "Sirius")
        self.assertEqual(star.mass, 3.978e30)
        self.assertEqual(star.type, "A-type")


    def test_str_sun(self):
        """
        Tests the __str__ method using the Sun as an example.
        Verifies correct formatting and attribute assignment.
        """
        sun = Star("Sun", 1.99e30, "G-type") # mock star we use for testing

        expected = "Star Sun: Type= G-type, Mass=1.99e30 kg" # expected string output

        self.assertEqual(str(sun), expected) # assert equal for testing 

    def test_str_red_dwarf(self):
        """
        Tests the __str__ method with a red dwarf star.
        """
        star1 = Star("Proxima Centauri", 2.446e29, "M-type") #mock star we use for testing
        expected = "Star Proxima Centauri: Type=M-type, Mass=2.446e29 kg" # expected string output 
        self.assertEqual(str(star1), expected) # expected output for testing 

if __name__ == '__main__':
    unittest.main()


    """ testing star class by running unittests for attribuites and representations"""