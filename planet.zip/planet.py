"""
planet.py

This module defines the Planet class, which miodels a planets attributes such as mass , radius , distance form sun and orbital period, 
it uses class methods to calculate orbital speed , gravity and classify planet type"""

import math


class Planet:
    """
    A class to represent a planet.

    Attributes:
        name, 
        mass 
        radius 
        distance_from_sun
        orbital_period"""

    def __init__(self, name, mass, radius, distance, period):
        """
        Initialize a Planet object.
        """
        self.name = name
        self.mass = mass
        self.radius = radius
        self.distance_from_sun = distance
        self.orbital_period = period

    def orbital_speed(self):
        """
        Calculate the orbital speed of the planet.

        returns the orbital speed in k m/s using formula derived from physics"""
        G = 6.67430e-11
        radius_meters = self.radius * 1000 # converting radius from km to m 
        return G * self.mass / (radius_meters ** 2)

    def get_info(self):
        """
        Return a dictionary containing planet information and calculated values.
        such as orbital speed and surface gravity 
        """

        return {
            "name": self.name,
            "mass": self.mass,
            "radius": self.radius,
            "distance_from_sun": self.distance_from_sun,
            "orbital_period": self.orbital_period,
            "orbital_speed": self.orbital_speed(),
            "surface_gravity": self.surface_gravity()
        }

    def planet_type(self):
        """
        Classify the planet based on its mass and radius.
        uses a nested elseif loop to test and classify a planet as either terrestrial or gas giant 

        """

        if 1e23 < self.mass < 5e25 and 1500 <= self.radius <= 10000:

            return "Terrestrial"
        
        elif self.mass > 1e25 and self.radius > 30000:

            return "Gas Giant"
        
        else:
            return "Unknown"

    def is_habitable(self):
        """
        Determine whether the planet is habitable """

        if self.planet_type() == "Terrestrial": 
            return True 
        else: 
            return False
    
    
