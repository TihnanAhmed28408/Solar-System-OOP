import unittest
from star import Star


class TestStar(unittest.TestCase):
    """
    A test case class for testing the Star class 
    """
    
    def test_attributes(self):
        """
        Tests that the attributes are correctly assigned
        during initialization.
        """
        star = Star("Sirius", 3.978e30, "A-type")
        self.assertEqual(star.name, "Sirius")
        self.assertEqual(star.mass, 3.978e30)
        self.assertEqual(star.type, "A-type")

    def test_str_sun(self):
        """
        Tests the __str__ method using the Sun as an example.
        Verifies correct formatting and attribute assignment.
        """
        sun = Star("Sun", 1.99e30, "G-type")

        expected = "Star Sun: Type= G-type, Mass=1.99e30 kg"

        self.assertEqual(str(sun), expected)

    def test_str_red_dwarf(self):
        """
        Tests the __str__ method with a red dwarf star.
        """
        star1 = Star("Proxima Centauri", 2.446e29, "M-type")
        expected = "Star Proxima Centauri: Type=M-type, Mass=2.446e29 kg"
        self.assertEqual(str(star1), expected)

if __name__ == '__main__':
    unittest.main()