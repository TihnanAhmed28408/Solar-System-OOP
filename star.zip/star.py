"""
star.py

This module defines the Star class, representing a star
with a name, mass, and classification type as the relevant attributes
"""

class Star:
    """
    A class to represent a star.

    Attributes:
        name : The name of the star.
        mass : The mass of the star in kilograms.
        type : The classification type of the star (e.g., G-type, M-type).
    """

    def __init__(self, name, mass, star_type):
        """
        Initialize a Star object.

        Parameters:
            name: The name of the star.
            mass : The mass of the star in kilograms.
            star_type: The classification type of the star.

    
        """

        self.name = name
        self.mass = mass
        self.type = star_type

    def __str__(self):
        """
        Return a string representation of the Star object.

            str: A formatted string describing the star.
        """
        return f"Star {self.name}: Type={self.type}, Mass={self.mass} kg"